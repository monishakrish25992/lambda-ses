import json
import boto3
import os

s3 = boto3.resource('s3')


def main(event, context):
    print(json.dumps(event))
    msg = event['Records'][0]['Sns']['Message']
    # print("From SNS: " + msg)
    encode_msg = json.loads(msg)
    bucket = encode_msg['Records'][0]['s3']['bucket']['name']
    print("BUCKET NAME :" + bucket)
    key = encode_msg["Records"][0]["s3"]["object"]["key"]
    print("KEY NAME :" + key)

   
    s3.meta.client.download_file(bucket, key, '/tmp/file.csv')
    f = open("/tmp/file.csv", "r")
    
    content = []
    for row in f.readlines():

        content.append(row.strip('\n'))
        res=json.dumps(content)

    ses = boto3.client('ses', region_name='us-east-1')
    mail_from = os.environ['MAIL_FROM']
    mail_to = os.environ['MAIL_TO']
    emaiL_subject = 'file content '
    email_body =res
    response = ses.send_email(
        Source=mail_from,
        Destination={
            'ToAddresses': [
                mail_to,
            ]

        },
        Message={
            'Subject': {
                'Data': emaiL_subject
            },
            'Body': {
                'Text': {
                    'Data': email_body
                }
            }
        }
    )
    print(response)


